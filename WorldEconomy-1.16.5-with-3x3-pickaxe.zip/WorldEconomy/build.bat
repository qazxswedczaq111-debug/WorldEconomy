@echo off
cd /d "%~dp0"
echo Building WorldEconomy for Paper 1.16.5...
mvn package
if errorlevel 1 (
  echo Build failed. Check that Java JDK and Maven are installed and internet is available.
  pause
  exit /b 1
)
echo Done: target\WorldEconomy-1.16.5.jar
pause
