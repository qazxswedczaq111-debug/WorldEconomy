package com.example.worldeconomy;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.util.Vector;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.*;

public class WorldEconomy extends JavaPlugin implements Listener {
    private NamespacedKey starKey;
    private NamespacedKey minerKey;
    private final Set<UUID> miningExtraBlocks = new HashSet<>();
    private final Map<UUID, Double> balances = new HashMap<>();
    private final Map<UUID, Integer> pages = new HashMap<>();
    private final String prefix = ChatColor.GOLD + "[WorldShop] " + ChatColor.GRAY;
    private static final String ROOT = ChatColor.DARK_GREEN + "فروشگاه جهانی";
    private static final String SELL = ChatColor.DARK_GREEN + "فروش آیتم‌ها";

    @Override public void onEnable() {
        saveDefaultConfig();
        starKey = new NamespacedKey(this, "shop_star");
        minerKey = new NamespacedKey(this, "miner_pickaxe");
        loadBalances();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("WorldEconomy enabled for Paper 1.16.5");
    }
    @Override public void onDisable() { saveBalances(); }

    private void loadBalances() {
        if (getConfig().getConfigurationSection("balances") == null) return;
        for (String id : getConfig().getConfigurationSection("balances").getKeys(false)) {
            try { balances.put(UUID.fromString(id), getConfig().getDouble("balances." + id)); } catch (IllegalArgumentException ignored) {}
        }
    }
    private void saveBalances() {
        getConfig().set("balances", null);
        for (Map.Entry<UUID, Double> e : balances.entrySet()) getConfig().set("balances." + e.getKey(), e.getValue());
        saveConfig();
    }
    private double balance(Player p) { return balances.getOrDefault(p.getUniqueId(), getConfig().getDouble("economy.starting-balance", 100.0)); }
    private void setBalance(Player p, double amount) { balances.put(p.getUniqueId(), Math.max(0, amount)); saveBalances(); }
    private ItemStack named(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material); ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.RESET + name); if (lore != null) meta.setLore(lore); item.setItemMeta(meta); return item;
    }
    private ItemStack star() {
        ItemStack item = named(Material.NETHER_STAR, getConfig().getString("star.name", "§6فروشگاه جهانی"), Arrays.asList("§7راست‌کلیک: باز کردن فروشگاه", "§8این آیتم قابل حذف نیست"));
        ItemMeta meta = item.getItemMeta(); meta.getPersistentDataContainer().set(starKey, PersistentDataType.BYTE, (byte)1); item.setItemMeta(meta); return item;
    }
    private boolean isStar(ItemStack item) {
        if (item == null || item.getType() != Material.NETHER_STAR || !item.hasItemMeta()) return false;
        Byte b = item.getItemMeta().getPersistentDataContainer().get(starKey, PersistentDataType.BYTE); return b != null && b == (byte)1;
    }
    private void ensureStar(Player p) {
        for (ItemStack it : p.getInventory().getContents()) if (isStar(it)) return;
        if (p.getInventory().firstEmpty() >= 0) p.getInventory().addItem(star());
    }
    private ItemStack minerPickaxe() {
        ItemStack item = new ItemStack(Material.DIAMOND_PICKAXE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "کلنگ ماینر 3x3");
        meta.setLore(Arrays.asList(ChatColor.GRAY + "شکستن بلوک‌ها در محدوده 3x3", ChatColor.DARK_GRAY + "مصرف دوام عادی"));
        meta.getPersistentDataContainer().set(minerKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        item.addEnchantment(Enchantment.DIG_SPEED, 3);
        item.addEnchantment(Enchantment.DURABILITY, 3);
        return item;
    }
    private boolean isMiner(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_PICKAXE || !item.hasItemMeta()) return false;
        Byte b = item.getItemMeta().getPersistentDataContainer().get(minerKey, PersistentDataType.BYTE);
        return b != null && b == (byte) 1;
    }
    @EventHandler public void onMinerBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (!isMiner(tool) || e.isCancelled() || !getConfig().getBoolean("miner.enabled", true)) return;
        Block center = e.getBlock();
        // Choose a 3x3 plane perpendicular to the player's horizontal facing direction.
        BlockFace facing = p.getFacing();
        boolean alongX = facing == BlockFace.NORTH || facing == BlockFace.SOUTH;
        int[][] offsets = alongX
                ? new int[][]{{-1,-1},{0,-1},{1,-1},{-1,0},{1,0},{-1,1},{0,1},{1,1}}
                : new int[][]{{-1,-1},{0,-1},{1,-1},{-1,0},{1,0},{-1,1},{0,1},{1,1}};
        for (int[] off : offsets) {
            Block extra = alongX ? center.getRelative(off[0], off[1], 0) : center.getRelative(0, off[1], off[0]);
            if (extra.getType().isAir() || extra.getType().getHardness() < 0) continue;
            if (extra.getType() == Material.BEDROCK || extra.getType() == Material.END_PORTAL_FRAME || extra.getType() == Material.END_PORTAL || extra.getType() == Material.NETHER_PORTAL) continue;
            // Respect other plugins' protection by dispatching a normal break event for each extra block.
            BlockBreakEvent extraEvent = new BlockBreakEvent(extra, p);
            Bukkit.getPluginManager().callEvent(extraEvent);
            if (extraEvent.isCancelled()) continue;
            extra.breakNaturally(tool);
            if (tool.getType() != Material.AIR && tool.getItemMeta() != null && tool.getItemMeta().isUnbreakable() == false) {
                if (tool.getType() != Material.AIR && tool.getItemMeta() != null && tool.getItemMeta().hasEnchants()) {
                    // Vanilla durability is applied by the normal center break; extra blocks have a small extra durability cost.
                    if (Math.random() < 0.15) tool.setDurability((short) (tool.getDurability() + 1));
                }
            }
            if (tool.getDurability() >= tool.getType().getMaxDurability()) { p.getInventory().setItemInMainHand(new ItemStack(Material.AIR)); break; }
        }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { Bukkit.getScheduler().runTask(this, () -> ensureStar(e.getPlayer())); }
    @EventHandler public void onDeath(PlayerDeathEvent e) { e.getDrops().removeIf(this::isStar); }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { Bukkit.getScheduler().runTask(this, () -> ensureStar(e.getPlayer())); }
    @EventHandler public void onDrop(PlayerDropItemEvent e) { if (isStar(e.getItemDrop().getItemStack())) { e.setCancelled(true); e.getPlayer().sendMessage(prefix + "نمی‌توانی ستاره فروشگاه را دراپ کنی."); } }
    @EventHandler public void onPickup(EntityPickupItemEvent e) { if (e.getEntity() instanceof Player && isStar(e.getItem().getItemStack())) e.setCancelled(true); }
    @EventHandler public void onClick(InventoryClickEvent e) {
        if (isStar(e.getCurrentItem()) || isStar(e.getCursor())) {
            if (e.getClickedInventory() != null && e.getClickedInventory() != e.getWhoClicked().getInventory()) { e.setCancelled(true); return; }
            if (e.isShiftClick() || e.getClick().isKeyboardClick() || e.getClick().name().contains("DROP") || e.getAction().name().contains("DROP")) e.setCancelled(true);
        }
        if (!(e.getWhoClicked() instanceof Player) || e.getView().getTitle() == null) return;
        String title = e.getView().getTitle();
        if (!title.startsWith(ROOT) && !title.startsWith("§2دسته: ") && !title.equals(SELL)) return;
        e.setCancelled(true);
        Player p = (Player)e.getWhoClicked(); ItemStack clicked = e.getCurrentItem(); if (clicked == null || clicked.getType() == Material.AIR) return;
        if (title.startsWith(ROOT)) {
            switch (clicked.getType()) {
                case EMERALD: openCategory(p, "resources", 0); break;
                case STONE: openCategory(p, "blocks", 0); break;
                case WHEAT: openCategory(p, "farming", 0); break;
                case DIAMOND_SWORD: openCategory(p, "pvp", 0); break;
                case REDSTONE: openCategory(p, "redstone", 0); break;
                case IRON_PICKAXE: openCategory(p, "tools", 0); break;
                case GOLD_INGOT: openSell(p); break;
                case BOOK: p.closeInventory(); p.sendMessage(prefix + "موجودی شما: §a" + money(balance(p))); break;
                default: break;
            }
            return;
        }
        if (title.equals(SELL)) { if (clicked.getType() == Material.BARRIER) p.closeInventory(); else sellInventory(p); return; }
        String cat = categoryFromTitle(title); int page = pages.getOrDefault(p.getUniqueId(), 0);
        if (clicked.getType() == Material.ARROW) { if (e.getSlot() == 45) page = Math.max(0, page - 1); else page++; openCategory(p, cat, page); return; }
        if (clicked.getType() == Material.BARRIER) { openRoot(p); return; }
        Material mat = clicked.getType(); double price = getConfig().getDouble("prices." + mat.name() + ".buy", -1);
        if (price < 0) { p.sendMessage(prefix + "این آیتم برای خرید تنظیم نشده است."); return; }
        if (balance(p) < price) { p.sendMessage(prefix + "پول کافی نداری. قیمت: " + money(price)); return; }
        Map<Integer, ItemStack> leftover = p.getInventory().addItem(new ItemStack(mat, 1));
        if (!leftover.isEmpty()) { p.sendMessage(prefix + "اینونتوری‌ات جا ندارد."); return; }
        setBalance(p, balance(p) - price); p.sendMessage(prefix + "خریدی: " + mat.name() + " به قیمت " + money(price));
    }
    @EventHandler public void onDrag(InventoryDragEvent e) {
        if (isStar(e.getOldCursor())) { for (int slot : e.getRawSlots()) if (slot < e.getView().getTopInventory().getSize()) { e.setCancelled(true); return; } }
        String t = e.getView().getTitle(); if (t != null && (t.startsWith(ROOT) || t.startsWith("§2دسته: ") || t.equals(SELL))) e.setCancelled(true);
    }
    @EventHandler public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK)) return;
        if (isStar(e.getItem())) { e.setCancelled(true); openRoot(e.getPlayer()); }
    }
    private void openRoot(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, ROOT);
        inv.setItem(10, named(Material.STONE, "§fبلوک‌ها", Arrays.asList("§7خرید بلوک‌های ساخت‌وساز")));
        inv.setItem(11, named(Material.EMERALD, "§aمنابع", Arrays.asList("§7سنگ معدن و منابع")));
        inv.setItem(12, named(Material.WHEAT, "§eکشاورزی و غذا", null));
        inv.setItem(13, named(Material.GOLD_INGOT, "§6فروش آیتم‌های اینونتوری", Arrays.asList("§7تمام آیتم‌های قابل فروش را بفروش")));
        inv.setItem(14, named(Material.DIAMOND_SWORD, "§cPvP", Arrays.asList("§7تجهیزات جنگی ویژه")));
        inv.setItem(15, named(Material.REDSTONE, "§cردستون", null));
        inv.setItem(16, named(Material.IRON_PICKAXE, "§bابزار ویژه", null));
        inv.setItem(22, named(Material.BOOK, "§fموجودی پول", Arrays.asList("§a" + money(balance(p)))));
        p.openInventory(inv);
    }
    private String categoryFromTitle(String title) { String s = title.substring("§2دسته: ".length()); for (String k : Arrays.asList("blocks","resources","farming","pvp","redstone","tools")) if (getConfig().getString("categories."+k+".title",k).equals(s)) return k; return "blocks"; }
    private List<Material> materialsFor(String category) {
        List<String> configured = getConfig().getStringList("categories." + category + ".items"); List<Material> result = new ArrayList<>();
        if (!configured.isEmpty()) { for (String s : configured) { Material m = Material.matchMaterial(s); if (m != null && m.isItem()) result.add(m); } }
        else for (Material m : Material.values()) if (m.isItem() && getConfig().contains("prices." + m.name() + ".buy")) result.add(m);
        result.sort(Comparator.comparing(Material::name)); return result;
    }
    private void openCategory(Player p, String category, int page) {
        String title = "§2دسته: " + getConfig().getString("categories." + category + ".title", category);
        Inventory inv = Bukkit.createInventory(null, 54, title); List<Material> items = materialsFor(category); int start = page * 45;
        for (int i=0; i<45 && start+i<items.size(); i++) { Material m = items.get(start+i); double price = getConfig().getDouble("prices."+m.name()+".buy", -1); inv.setItem(i, named(m, "§f"+pretty(m.name()), Arrays.asList("§7قیمت خرید: §a"+money(price), "§eبرای خرید کلیک کن"))); }
        inv.setItem(45, named(Material.ARROW, "§fصفحه قبل", null)); inv.setItem(49, named(Material.BARRIER, "§cبازگشت", null)); inv.setItem(53, named(Material.ARROW, "§fصفحه بعد", null)); pages.put(p.getUniqueId(), page); p.openInventory(inv);
    }
    private void openSell(Player p) { Inventory inv = Bukkit.createInventory(null, 27, SELL); inv.setItem(13, named(Material.GOLD_INGOT, "§6فروش همه آیتم‌های قابل فروش", Arrays.asList("§7قیمت‌ها در config.yml قابل تنظیم هستند"))); inv.setItem(22, named(Material.BARRIER, "§cبازگشت", null)); p.openInventory(inv); }
    private void sellInventory(Player p) {
        double total = 0; int count = 0;
        for (int i=0; i<p.getInventory().getSize(); i++) { ItemStack it = p.getInventory().getItem(i); if (it == null || it.getType() == Material.AIR || isStar(it)) continue;
            double unit = getConfig().getDouble("prices."+it.getType().name()+".sell", getConfig().getDouble("economy.default-sell-price", 0.05)); if (unit < 0) continue;
            total += unit * it.getAmount(); count += it.getAmount(); p.getInventory().setItem(i, null);
        }
        if (total > 0) { setBalance(p, balance(p)+total); p.sendMessage(prefix + "§a"+count+" آیتم فروختی و "+money(total)+" دریافت کردی."); }
        else p.sendMessage(prefix + "آیتم قابل فروش در اینونتوری پیدا نشد."); p.closeInventory();
    }
    private String pretty(String s) { return s.toLowerCase(Locale.ROOT).replace('_',' '); }
    private String money(double v) { return String.format(Locale.US, "%.2f", v); }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd=command.getName().toLowerCase(Locale.ROOT);
        if(cmd.equals("balance") || cmd.equals("bal")) { if(!(sender instanceof Player)){sender.sendMessage("Players only");return true;} Player p=(Player)sender; sender.sendMessage(prefix+"موجودی: §a"+money(balance(p))); return true; }
        if(cmd.equals("pay")) { if(!(sender instanceof Player)||args.length!=2){sender.sendMessage("استفاده: /pay <player> <amount>");return true;} Player p=(Player)sender, target=Bukkit.getPlayerExact(args[0]); double amount; try{amount=Double.parseDouble(args[1]);}catch(NumberFormatException ex){sender.sendMessage("مبلغ نامعتبر است.");return true;} if(target==null||target.equals(p)||amount<=0||!Double.isFinite(amount)||balance(p)<amount){sender.sendMessage("بازیکن یا مبلغ نامعتبر است، یا پول کافی نداری.");return true;} setBalance(p,balance(p)-amount);setBalance(target,balance(target)+amount);p.sendMessage(prefix+"انتقال انجام شد.");target.sendMessage(prefix+"§a"+money(amount)+" از "+p.getName()+" دریافت کردی.");return true; }
        if(cmd.equals("worldshop")) { if(args.length>0 && args[0].equalsIgnoreCase("reload")){if(!sender.hasPermission("worldeconomy.admin")){sender.sendMessage("اجازه نداری.");return true;}reloadConfig();sender.sendMessage(prefix+"کانفیگ دوباره بارگذاری شد.");return true;} if(sender instanceof Player)openRoot((Player)sender);else sender.sendMessage("Players only");return true; }
        if(cmd.equals("shopitem")) { if(!(sender instanceof Player)||!sender.hasPermission("worldeconomy.admin")){sender.sendMessage("اجازه نداری.");return true;} Player p=(Player)sender; if(args.length>0 && args[0].equalsIgnoreCase("miner")){p.getInventory().addItem(minerPickaxe());p.sendMessage(prefix+"کلنگ ماینر 3x3 دریافت شد.");return true;} ItemStack[] kit = pvpKit(); for(ItemStack it:kit)p.getInventory().addItem(it); sender.sendMessage(prefix+"کیت PvP دریافت شد.");return true; }
        return false;
    }
    private ItemStack[] pvpKit() {
        ItemStack sword=new ItemStack(Material.DIAMOND_SWORD); sword.addEnchantment(Enchantment.DAMAGE_ALL,5); sword.addEnchantment(Enchantment.FIRE_ASPECT,2); sword.addEnchantment(Enchantment.DURABILITY,3); sword.addEnchantment(Enchantment.LOOT_BONUS_MOBS,3);
        ItemStack axe=new ItemStack(Material.DIAMOND_AXE); axe.addEnchantment(Enchantment.DAMAGE_UNDEAD,5); axe.addEnchantment(Enchantment.DAMAGE_ALL,5); axe.addEnchantment(Enchantment.DURABILITY,3);
        ItemStack bow=new ItemStack(Material.BOW); bow.addEnchantment(Enchantment.ARROW_DAMAGE,5); bow.addEnchantment(Enchantment.ARROW_FIRE,1); bow.addEnchantment(Enchantment.ARROW_INFINITE,1); bow.addEnchantment(Enchantment.DURABILITY,3);
        ItemStack helmet=new ItemStack(Material.DIAMOND_HELMET); helmet.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL,4); helmet.addEnchantment(Enchantment.DURABILITY,3);
        ItemStack chest=new ItemStack(Material.DIAMOND_CHESTPLATE); chest.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL,4); chest.addEnchantment(Enchantment.DURABILITY,3);
        ItemStack legs=new ItemStack(Material.DIAMOND_LEGGINGS); legs.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL,4); legs.addEnchantment(Enchantment.DURABILITY,3);
        ItemStack boots=new ItemStack(Material.DIAMOND_BOOTS); boots.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL,4); boots.addEnchantment(Enchantment.DURABILITY,3);
        return new ItemStack[]{sword,axe,bow,helmet,chest,legs,boots,new ItemStack(Material.FIRE_CHARGE,16),new ItemStack(Material.ARROW,1)};
    }
}
